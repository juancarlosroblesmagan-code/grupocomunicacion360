# Changelog

## Pendiente — revisión QA local

- El límite de longitud de las consultas REST se mide en caracteres UTF-8, no en bytes; conserva correctamente el margen configurado para texto en español.

## 0.2.0-dev — 24/11/2026

- Reconstrucción local inicial, independiente del prototipo 0.1.0.
- Núcleo modular, activación/desactivación y tablas propias para límites y estadísticas minimizadas.
- Cliente servidor para Responses API sin clave embebida, con `store: false`.
- Endpoint con sesión temporal HttpOnly, nonce, límite global y por visitante seudonimizado.
- Interfaz pública inicial accesible y enlace manual a WhatsApp.
- Sin activación pública ni llamadas reales a OpenAI.
