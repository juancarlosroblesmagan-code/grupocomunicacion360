# 360º AI Assistant PRO — 0.2.0-dev

Entrega de desarrollo. La copia presente en producción está instalada pero inactiva; no está autorizada su activación pública.

Requiere WordPress 6.4+, PHP 7.4+ y una clave configurada solo en servidor como `A360_OPENAI_API_KEY`. Nunca introduzcas la clave en el panel, JavaScript, repositorios o ZIP.

Mantén el modo de pruebas hasta superar el plan de QA. Los documentos se gestionan en **Asistente 360º > Base de conocimiento** y solo los aprobados se pueden usar como contexto.
