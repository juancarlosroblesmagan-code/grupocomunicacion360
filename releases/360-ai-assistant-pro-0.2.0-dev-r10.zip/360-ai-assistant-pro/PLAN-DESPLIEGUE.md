# Plan de despliegue

1. Copia verificada y staging autorizado.
2. Instalar sin activar el chat público.
3. Configurar clave fuera del plugin, privacidad, presupuesto y documentos aprobados.
4. Ejecutar QA y una llamada real controlada autorizada.
5. Medir compatibilidad con Brooklyn, WPBakery, WP Rocket y Complianz.
6. Publicar solo con autorización expresa.
